const Editor = {
  async insertTextAtCursor(text) {
    return text
  },
}

module.exports = Editor
